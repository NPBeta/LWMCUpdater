# Continuum 2.1 ALPHA

This a Minecraft shaderpack. It is the natural Evolution of Continuum 2.0, it is intended to lean towards high-end and cutting-edge effects, but will also have a stronger focus on optimization vs 2.0. Continuum 2.1 is being developed by multiple experienced people, who basically work full-time on it at points; as such, we are charging money for it.

[Our Discord.](https://discord.gg/XkzyWZb) 

[Our Website.](https://continuum.graphics/)

We are also on the [Shaderlabs Discord.](https://discordapp.com/invite/F4BtNAc)  


## Planned Features 
- PBR Material Support (POM, PBR Specular, PBR Diffuse) 
- PBR Photometric Lighting System (PBR HDR Lighting) 
- PBR Camera System (Exposure, Grain, Motion Blur, DoF) 
- ACES Color Grading with configurable LMT
- PBR Volumetrics (VL, Clouds, Water Fog) 
- Stochastic Screen Space Reflections
- Global Illumination (RSM) 
- GTAO (Screen Space Ground Truth AO) 
- HRT Shadows (Hybrid Ray Traced Shadows) 
- Volumetric Clouds with proper Aerial Perspective Atmospheric Scattering
- Dynamic Weather and Wind Systems
- High Quality and Highly Configurable TAA (Temporal Anti-Aliasing)

## Requirements
- High-end hardware (Nvidia GPU's are preferred at this time, AMD support may be lacking, and Intel HD is not officially supported at all at this time. Hardware compatibility may change as development progresses.
- **Optifine HD U F2 Pre3** or **later**. Make sure you have the latest Optifine before you complain about anything. You can get them [here](https://optifine.net/downloads).
- A relatively new Nvidia driver version (if you're using Nvidia GPU), you can find the latest [here](https://www.geforce.com/drivers). This has not been tested with AMD much, but getting a somewhat new AMD driver might be a good idea as well. 

## Installation
- Watch [this video by FernFox](https://www.youtube.com/watch?v=t5QFNc9rhNc), using this download of 2.1 Alpha in place of 2.0.4.

## FAQ
- If the shader does not function correctly (shows a black or white screen, doesn't work, etc), make sure you are adhering to the requirements; not using Intel HD Graphics, and using the proper Optifine version(s).
- Please do not report this or other missing features as bugs. We are well aware of them and are working to implement them.

## Known Issues/Bugs
- Poor/no AMD GPU compatibility. Testing for this will likely occur near the end of Alpha or in Beta. 
- Shadow resolutions above 2048 can be display some visual anomolies. 
- Some minor shadow striping issues are present in some scenarios.
- Some autocam issues when looking at objects that have near/pure black.

## Rules  
- This shader costs money, don't share it. 